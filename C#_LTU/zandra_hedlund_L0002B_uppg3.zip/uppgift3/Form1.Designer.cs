﻿namespace uppgift3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonOk = new System.Windows.Forms.Button();
            this.buttonAvsluta = new System.Windows.Forms.Button();
            this.textBoxFornamn = new System.Windows.Forms.TextBox();
            this.textBoxEfternamn = new System.Windows.Forms.TextBox();
            this.textBoxPersonnr = new System.Windows.Forms.TextBox();
            this.labelFornamn = new System.Windows.Forms.Label();
            this.labelEfternamn = new System.Windows.Forms.Label();
            this.labelPersonnr = new System.Windows.Forms.Label();
            this.subtitle = new System.Windows.Forms.Label();
            this.title = new System.Windows.Forms.Label();
            this.textBoxResultat = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.registreraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registreraToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.avslutaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonOk
            // 
            this.buttonOk.Location = new System.Drawing.Point(262, 162);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(75, 23);
            this.buttonOk.TabIndex = 0;
            this.buttonOk.Text = "Ok";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.okClick);
            // 
            // buttonAvsluta
            // 
            this.buttonAvsluta.Location = new System.Drawing.Point(262, 191);
            this.buttonAvsluta.Name = "buttonAvsluta";
            this.buttonAvsluta.Size = new System.Drawing.Size(75, 23);
            this.buttonAvsluta.TabIndex = 1;
            this.buttonAvsluta.Text = "Avsluta";
            this.buttonAvsluta.UseVisualStyleBackColor = true;
            this.buttonAvsluta.Click += new System.EventHandler(this.avslutaClick);
            // 
            // textBoxFornamn
            // 
            this.textBoxFornamn.Location = new System.Drawing.Point(144, 96);
            this.textBoxFornamn.Name = "textBoxFornamn";
            this.textBoxFornamn.Size = new System.Drawing.Size(100, 20);
            this.textBoxFornamn.TabIndex = 2;
            // 
            // textBoxEfternamn
            // 
            this.textBoxEfternamn.Location = new System.Drawing.Point(144, 127);
            this.textBoxEfternamn.Name = "textBoxEfternamn";
            this.textBoxEfternamn.Size = new System.Drawing.Size(100, 20);
            this.textBoxEfternamn.TabIndex = 3;
            // 
            // textBoxPersonnr
            // 
            this.textBoxPersonnr.Location = new System.Drawing.Point(144, 164);
            this.textBoxPersonnr.Name = "textBoxPersonnr";
            this.textBoxPersonnr.Size = new System.Drawing.Size(100, 20);
            this.textBoxPersonnr.TabIndex = 4;
            // 
            // labelFornamn
            // 
            this.labelFornamn.AutoSize = true;
            this.labelFornamn.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFornamn.Location = new System.Drawing.Point(82, 99);
            this.labelFornamn.Name = "labelFornamn";
            this.labelFornamn.Size = new System.Drawing.Size(56, 17);
            this.labelFornamn.TabIndex = 5;
            this.labelFornamn.Text = "Förnamn:";
            // 
            // labelEfternamn
            // 
            this.labelEfternamn.AutoSize = true;
            this.labelEfternamn.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEfternamn.Location = new System.Drawing.Point(82, 128);
            this.labelEfternamn.Name = "labelEfternamn";
            this.labelEfternamn.Size = new System.Drawing.Size(61, 17);
            this.labelEfternamn.TabIndex = 6;
            this.labelEfternamn.Text = "Efternamn:";
            // 
            // labelPersonnr
            // 
            this.labelPersonnr.AutoSize = true;
            this.labelPersonnr.Font = new System.Drawing.Font("Arial Narrow", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPersonnr.Location = new System.Drawing.Point(82, 164);
            this.labelPersonnr.Name = "labelPersonnr";
            this.labelPersonnr.Size = new System.Drawing.Size(57, 17);
            this.labelPersonnr.TabIndex = 7;
            this.labelPersonnr.Text = "Personnr:";
            // 
            // subtitle
            // 
            this.subtitle.AutoSize = true;
            this.subtitle.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subtitle.Location = new System.Drawing.Point(82, 69);
            this.subtitle.Name = "subtitle";
            this.subtitle.Size = new System.Drawing.Size(230, 16);
            this.subtitle.TabIndex = 8;
            this.subtitle.Text = "Ange namn och personnummer:";
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Font = new System.Drawing.Font("Arial", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title.ForeColor = System.Drawing.Color.Red;
            this.title.Location = new System.Drawing.Point(80, 33);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(119, 24);
            this.title.TabIndex = 9;
            this.title.Text = "Välkommen";
            // 
            // textBoxResultat
            // 
            this.textBoxResultat.Location = new System.Drawing.Point(90, 212);
            this.textBoxResultat.Multiline = true;
            this.textBoxResultat.Name = "textBoxResultat";
            this.textBoxResultat.Size = new System.Drawing.Size(154, 99);
            this.textBoxResultat.TabIndex = 10;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registreraToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // registreraToolStripMenuItem
            // 
            this.registreraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registreraToolStripMenuItem1,
            this.avslutaToolStripMenuItem});
            this.registreraToolStripMenuItem.Name = "registreraToolStripMenuItem";
            this.registreraToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.registreraToolStripMenuItem.Text = "Alternativ";
            // 
            // registreraToolStripMenuItem1
            // 
            this.registreraToolStripMenuItem1.Name = "registreraToolStripMenuItem1";
            this.registreraToolStripMenuItem1.Size = new System.Drawing.Size(183, 22);
            this.registreraToolStripMenuItem1.Text = "Registrera person";
            this.registreraToolStripMenuItem1.Click += new System.EventHandler(this.registreraToolStripMenuItem_Click);
            // 
            // avslutaToolStripMenuItem
            // 
            this.avslutaToolStripMenuItem.Name = "avslutaToolStripMenuItem";
            this.avslutaToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.avslutaToolStripMenuItem.Text = "Avsluta programmet";
            this.avslutaToolStripMenuItem.Click += new System.EventHandler(this.avslutaToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBoxResultat);
            this.Controls.Add(this.title);
            this.Controls.Add(this.subtitle);
            this.Controls.Add(this.labelPersonnr);
            this.Controls.Add(this.labelEfternamn);
            this.Controls.Add(this.labelFornamn);
            this.Controls.Add(this.textBoxPersonnr);
            this.Controls.Add(this.textBoxEfternamn);
            this.Controls.Add(this.textBoxFornamn);
            this.Controls.Add(this.buttonAvsluta);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonOk;
        private System.Windows.Forms.Button buttonAvsluta;
        private System.Windows.Forms.TextBox textBoxFornamn;
        private System.Windows.Forms.TextBox textBoxEfternamn;
        private System.Windows.Forms.TextBox textBoxPersonnr;
        private System.Windows.Forms.Label labelFornamn;
        private System.Windows.Forms.Label labelEfternamn;
        private System.Windows.Forms.Label labelPersonnr;
        private System.Windows.Forms.Label subtitle;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.TextBox textBoxResultat;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem registreraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registreraToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem avslutaToolStripMenuItem;
    }
}

