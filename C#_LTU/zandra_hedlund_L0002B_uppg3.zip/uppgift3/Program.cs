﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uppgift3
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }

public class Person
    {
        public string Förnamn { get; set; }
        public string Efternamn { get; set; }
        public string Personnummer { get; set; }

        public Person(string förnamn, string efternamn, string personnummer)
        {
            Förnamn = förnamn;
            Efternamn = efternamn;
            Personnummer = personnummer;
        }

        public bool korrektPersonnummer()
        {
            string personnummerStripped = Personnummer.Replace("-", ""); // Ta bort eventuellt bindestreck

            // Kontrollerar att längden 10 och består av siffror
            if (personnummerStripped.Length != 10 || !personnummerStripped.All(char.IsDigit))
            {
                return false; 
            }

            int summa = 0;
            for (int i = 0; i < 9; i++)
            {
                int siffra = int.Parse(personnummerStripped[i].ToString());
                int faktor = i % 2 == 0 ? 2 : 1;
                int produkt = siffra * faktor;
                summa += produkt >= 10 ? produkt - 9 : produkt;
            }

            int sistaSiffran = int.Parse(personnummerStripped[9].ToString());
            int kontrollsiffra = (10 - (summa % 10)) % 10;

            return sistaSiffran == kontrollsiffra;
        }
        public string avgörKön()
        {
            int nästSistaSiffran = int.Parse(Personnummer.Substring(8, 1));

            if (nästSistaSiffran % 2 == 0)
            {
                return "Kvinna";
            }
            else
            {
                return "Man";
            }
        }

    }

}
