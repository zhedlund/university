﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uppgift3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Döjer formulär inledningsvis
            textBoxFornamn.Visible = false;
            textBoxEfternamn.Visible = false;
            textBoxPersonnr.Visible = false;
            labelFornamn.Visible = false;
            labelEfternamn.Visible = false;
            labelPersonnr.Visible = false;
            subtitle.Visible = false;
            buttonOk.Visible = false;
            buttonAvsluta.Visible = false;
            textBoxResultat.Visible = false;
        }

        private void avslutaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void registreraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Visar formulär om "Registrera person" väljs
            textBoxFornamn.Visible = true;
            textBoxEfternamn.Visible = true;
            textBoxPersonnr.Visible = true;
            labelFornamn.Visible = true;
            labelEfternamn.Visible = true;
            labelPersonnr.Visible = true;
            subtitle.Visible = true;
            buttonOk.Visible = true;
            buttonAvsluta.Visible = true;
            textBoxResultat.Visible = true;
        }

        private void okClick(object sender, EventArgs e)
        {
            // Skapar instans av Person-klassen med angivna uppgifter
            Person person = new Person(textBoxFornamn.Text, textBoxEfternamn.Text, textBoxPersonnr.Text);

            // Kontrollera giltigheten av personnr
            if (person.korrektPersonnummer())
            {
                // Om giltigt personnr, bestäm kön och visa resultatet
                string kön = person.avgörKön();
                string formateratPersonnummer = person.Personnummer.Insert(6, "-"); // Infoga bindestreck vid rätt position
                textBoxResultat.Text = $"Förnamn: {person.Förnamn}\r\nEfternamn: {person.Efternamn}\r\nPersonnummer: {formateratPersonnummer}\r\nKön: {kön}";
            }
            else
            {
                // Om ogiltigt personnr, visa felmeddelande
                textBoxResultat.Text = "Ogiltigt personnummer";
            }
        }
        private void avslutaClick(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
